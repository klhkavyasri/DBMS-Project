from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
import os
import re
from werkzeug.utils import secure_filename
from PyPDF2 import PdfReader
from docx import Document

app = Flask(__name__)
CORS(app)

# ==============================
# MYSQL
# ==============================

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="job_portal",
    autocommit=False
)

print("MySQL connected successfully!")


def get_db():
    return db


# ==============================
# HOME
# ==============================

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "message": "JobMatch Backend is Running!"
    })


# ==============================
# REGISTER
# ==============================

@app.route("/register", methods=["POST"])
def register():

    data = request.get_json()

    name = data.get("name")
    email = data.get("email")
    password = data.get("password")
    role = data.get("role")

    if not name or not email or not password or not role:
        return jsonify({
            "message": "All fields are required."
        }), 400

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            INSERT INTO users
            (name, email, password, role)
            VALUES (%s, %s, %s, %s)
            """,
            (name, email, password, role)
        )

        user_id = cursor.lastrowid

        # Create related profile
        if role == "Job Seeker":

            cursor.execute(
                """
                INSERT INTO job_seeker_profiles
                (user_id, education, skills, experience, certifications)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (user_id, "", "", "", "")
            )

        elif role == "Employer":

            cursor.execute(
                """
                INSERT INTO employers
                (user_id, company_name, company_description)
                VALUES (%s, %s, %s)
                """,
                (
                    user_id,
                    name,
                    "Technology company offering professional opportunities."
                )
            )

        db.commit()

        return jsonify({
            "message": "Account created successfully!",
            "user_id": user_id
        }), 201

    except mysql.connector.IntegrityError:

        db.rollback()

        return jsonify({
            "message": "This email is already registered."
        }), 409

    except mysql.connector.Error as error:

        db.rollback()

        print("Registration error:", error)

        return jsonify({
            "message": "Registration failed."
        }), 500

    finally:
        cursor.close()


# ==============================
# LOGIN
# ==============================

@app.route("/login", methods=["POST"])
def login():

    data = request.get_json()

    email = data.get("email")
    password = data.get("password")
    role = data.get("role")

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            SELECT user_id, name, email, role
            FROM users
            WHERE email = %s
            AND password = %s
            AND role = %s
            """,
            (email, password, role)
        )

        user = cursor.fetchone()

        if not user:
            return jsonify({
                "message": "Invalid email, password, or account type."
            }), 401

        return jsonify({
            "message": "Login successful!",
            "user_id": user["user_id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"]
        }), 200

    finally:
        cursor.close()


# ==============================
# GET ALL JOBS
# ==============================

@app.route("/jobs", methods=["GET"])
def get_jobs():

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            SELECT
                job_id,
                employer_id,
                job_title,
                description,
                required_skills
            FROM jobs
            ORDER BY job_id DESC
            """
        )

        jobs = cursor.fetchall()

        return jsonify(jobs), 200

    finally:
        cursor.close()


# ==============================
# PROFILE
# ==============================

@app.route("/profile/<int:user_id>", methods=["GET"])
def get_profile(user_id):

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            SELECT *
            FROM job_seeker_profiles
            WHERE user_id = %s
            """,
            (user_id,)
        )

        profile = cursor.fetchone()

        if not profile:
            return jsonify({
                "message": "Profile not found."
            }), 404

        return jsonify(profile), 200

    finally:
        cursor.close()


# ==============================
# RESUME PARSER
# ==============================

KNOWN_SKILLS = [
    "Python",
    "Java",
    "C++",
    "C",
    "JavaScript",
    "React",
    "HTML",
    "CSS",
    "SQL",
    "MySQL",
    "MongoDB",
    "Flask",
    "Django",
    "Git",
    "GitHub",
    "Machine Learning",
    "Scikit-learn",
    "Pandas",
    "NumPy",
    "TensorFlow",
    "PyTorch",
    "Excel",
    "Power BI",
    "Data Analysis"
]

KNOWN_CERTIFICATIONS = [
    "MongoDB Associate",
    "MongoDB",
    "AWS Certified",
    "Azure",
    "Google Cloud",
    "Python Certification",
    "Java Certification",
    "Microsoft Certified",
    "Credly"
]


def extract_skills(text):

    found = []

    lower_text = text.lower()

    for skill in KNOWN_SKILLS:

        skill_lower = skill.lower()

        if skill_lower == "c":

            if re.search(r"\b(c|c programming|c language)\b", lower_text):
                found.append(skill)

        elif skill_lower in lower_text:
            found.append(skill)

    return ", ".join(dict.fromkeys(found))


def extract_education(text):

    education_keywords = [
        "b.tech",
        "btech",
        "b.e",
        "be ",
        "m.tech",
        "mtech",
        "mca",
        "bca",
        "degree",
        "bachelor",
        "master",
        "engineering"
    ]

    lines = text.splitlines()

    found = []

    for line in lines:

        clean = line.strip()

        if not clean:
            continue

        lower = clean.lower()

        for keyword in education_keywords:

            if keyword in lower:
                found.append(clean)
                break

    return ", ".join(dict.fromkeys(found))[:200]


def extract_experience(text):

    patterns = [
        r"\d+\+?\s*(?:years?|yrs?)\s*(?:of)?\s*experience",
        r"internship",
        r"intern",
        r"work experience"
    ]

    lines = text.splitlines()

    found = []

    for line in lines:

        clean = line.strip()

        if not clean:
            continue

        lower = clean.lower()

        for pattern in patterns:

            if re.search(pattern, lower):
                found.append(clean)
                break

    return ", ".join(dict.fromkeys(found))[:200]


def extract_certifications(text):

    found = []

    lower_text = text.lower()

    for certification in KNOWN_CERTIFICATIONS:

        if certification.lower() in lower_text:
            found.append(certification)

    return ", ".join(dict.fromkeys(found))


# ==============================
# UPLOAD RESUME
# ==============================

@app.route("/upload-resume", methods=["POST"])
def upload_resume():

    file = request.files.get("resume")
    user_id = request.form.get("user_id")

    if not file:
        return jsonify({
            "message": "Please select a resume."
        }), 400

    if not user_id:
        return jsonify({
            "message": "User ID is missing."
        }), 400

    filename = secure_filename(file.filename)

    extension = os.path.splitext(filename)[1].lower()

    if extension not in [".pdf", ".docx"]:
        return jsonify({
            "message": "Only PDF and DOCX files are supported."
        }), 400

    upload_folder = os.path.join(
        app.root_path,
        "uploads"
    )

    os.makedirs(upload_folder, exist_ok=True)

    file_path = os.path.join(
        upload_folder,
        filename
    )

    file.save(file_path)

    extracted_text = ""

    try:

        if extension == ".pdf":

            reader = PdfReader(file_path)

            for page in reader.pages:

                page_text = page.extract_text()

                if page_text:
                    extracted_text += page_text + "\n"

        else:

            document = Document(file_path)

            for paragraph in document.paragraphs:
                extracted_text += paragraph.text + "\n"

    except Exception as error:

        print("Resume parsing error:", error)

        return jsonify({
            "message": "Could not read the resume."
        }), 500

    skills = extract_skills(extracted_text)
    education = extract_education(extracted_text)
    experience = extract_experience(extracted_text)
    certifications = extract_certifications(extracted_text)

    cursor = db.cursor()

    try:

        cursor.execute(
            """
            INSERT INTO resumes
            (user_id, resume_file, extracted_text)
            VALUES (%s, %s, %s)
            """,
            (
                user_id,
                filename,
                extracted_text
            )
        )

        cursor.execute(
            """
            SELECT profile_id
            FROM job_seeker_profiles
            WHERE user_id = %s
            """,
            (user_id,)
        )

        profile = cursor.fetchone()

        if profile:

            cursor.execute(
                """
                UPDATE job_seeker_profiles
                SET
                    education = %s,
                    skills = %s,
                    experience = %s,
                    certifications = %s
                WHERE user_id = %s
                """,
                (
                    education,
                    skills,
                    experience,
                    certifications,
                    user_id
                )
            )

        else:

            cursor.execute(
                """
                INSERT INTO job_seeker_profiles
                (user_id, education, skills, experience, certifications)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    user_id,
                    education,
                    skills,
                    experience,
                    certifications
                )
            )

        db.commit()

        return jsonify({
            "message": "Resume uploaded and analyzed successfully!",
            "skills": skills,
            "education": education,
            "experience": experience,
            "certifications": certifications
        }), 201

    except mysql.connector.Error as error:

        db.rollback()

        print("Resume database error:", error)

        return jsonify({
            "message": "Resume could not be saved."
        }), 500

    finally:
        cursor.close()


# ==============================
# MATCH JOBS
# ==============================

@app.route("/match-jobs/<int:user_id>", methods=["GET"])
def match_jobs(user_id):

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            SELECT skills
            FROM job_seeker_profiles
            WHERE user_id = %s
            """,
            (user_id,)
        )

        profile = cursor.fetchone()

        if not profile:

            return jsonify({
                "user_id": user_id,
                "candidate_skills": "",
                "matches": []
            })

        candidate_skills = profile["skills"] or ""

        cursor.execute(
            """
            SELECT
                job_id,
                job_title,
                description,
                required_skills
            FROM jobs
            ORDER BY job_id DESC
            """
        )

        jobs = cursor.fetchall()

        matches = []

        candidate_words = [
            x.strip().lower()
            for x in candidate_skills.split(",")
            if x.strip()
        ]

        for job in jobs:

            required = job["required_skills"] or ""

            required_words = [
                x.strip().lower()
                for x in required.split(",")
                if x.strip()
            ]

            if not required_words:

                score = 0

            else:

                matched = sum(
                    1
                    for skill in required_words
                    if skill in candidate_words
                )

                score = round(
                    (matched / len(required_words)) * 100,
                    2
                )

            matches.append({
                "job_id": job["job_id"],
                "job_title": job["job_title"],
                "description": job["description"],
                "required_skills": job["required_skills"],
                "match_score": score
            })

            # Save/update score
            cursor.execute(
                """
                SELECT match_id
                FROM match_scores
                WHERE user_id = %s
                AND job_id = %s
                """,
                (user_id, job["job_id"])
            )

            existing = cursor.fetchone()

            if existing:

                cursor.execute(
                    """
                    UPDATE match_scores
                    SET score = %s
                    WHERE user_id = %s
                    AND job_id = %s
                    """,
                    (
                        score,
                        user_id,
                        job["job_id"]
                    )
                )

            else:

                cursor.execute(
                    """
                    INSERT INTO match_scores
                    (user_id, job_id, score)
                    VALUES (%s, %s, %s)
                    """,
                    (
                        user_id,
                        job["job_id"],
                        score
                    )
                )

        db.commit()

        matches.sort(
            key=lambda x: x["match_score"],
            reverse=True
        )

        return jsonify({
            "user_id": user_id,
            "candidate_skills": candidate_skills,
            "matches": matches
        }), 200

    finally:
        cursor.close()


# ==============================
# APPLY FOR JOB
# ==============================

@app.route("/apply", methods=["POST"])
def apply():

    data = request.get_json()

    user_id = data.get("user_id")
    job_id = data.get("job_id")

    if not user_id or not job_id:

        return jsonify({
            "message": "User ID and Job ID are required."
        }), 400

    cursor = db.cursor()

    try:

        cursor.execute(
            """
            SELECT application_id
            FROM applications
            WHERE user_id = %s
            AND job_id = %s
            """,
            (
                user_id,
                job_id
            )
        )

        existing = cursor.fetchone()

        if existing:

            return jsonify({
                "message": "You have already applied for this job."
            }), 409

        cursor.execute(
            """
            INSERT INTO applications
            (user_id, job_id, status)
            VALUES (%s, %s, %s)
            """,
            (
                user_id,
                job_id,
                "Applied"
            )
        )

        db.commit()

        return jsonify({
            "message": "Application submitted successfully!"
        }), 201

    except mysql.connector.Error as error:

        db.rollback()

        print("Application error:", error)

        return jsonify({
            "message": "Could not submit application."
        }), 500

    finally:
        cursor.close()


# ==============================
# JOB SEEKER APPLICATIONS
# ==============================

@app.route("/applications/<int:user_id>", methods=["GET"])
def get_applications(user_id):

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            SELECT
                a.application_id,
                a.user_id,
                a.job_id,
                a.status,
                j.job_title,
                j.description,
                j.required_skills,
                COALESCE(ms.score, 0) AS match_score
            FROM applications a
            JOIN jobs j
                ON a.job_id = j.job_id
            LEFT JOIN match_scores ms
                ON ms.user_id = a.user_id
                AND ms.job_id = a.job_id
            WHERE a.user_id = %s
            ORDER BY a.application_id DESC
            """,
            (user_id,)
        )

        applications = cursor.fetchall()

        return jsonify(applications), 200

    finally:
        cursor.close()


# ==============================
# EMPLOYER JOBS
# ==============================

@app.route("/employer/jobs/<int:user_id>", methods=["GET"])
def employer_jobs(user_id):

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            SELECT
                j.job_id,
                j.job_title,
                j.description,
                j.required_skills
            FROM jobs j
            JOIN employers e
                ON j.employer_id = e.employer_id
            WHERE e.user_id = %s
            ORDER BY j.job_id DESC
            """,
            (user_id,)
        )

        jobs = cursor.fetchall()

        return jsonify(jobs), 200

    finally:
        cursor.close()


# ==============================
# POST JOB
# ==============================

@app.route("/employer/jobs", methods=["POST"])
def post_employer_job():

    data = request.get_json()

    user_id = data.get("user_id")
    job_title = data.get("job_title")
    description = data.get("description")
    required_skills = data.get("required_skills")

    if not user_id or not job_title or not required_skills:

        return jsonify({
            "message": "Job title and required skills are required."
        }), 400

    cursor = db.cursor(dictionary=True)

    try:

        cursor.execute(
            """
            SELECT employer_id
            FROM employers
            WHERE user_id = %s
            """,
            (user_id,)
        )

        employer = cursor.fetchone()

        if not employer:

            return jsonify({
                "message": "Employer profile not found."
            }), 404

        cursor.execute(
            """
            INSERT INTO jobs
            (
                employer_id,
                job_title,
                description,
                required_skills
            )
            VALUES (%s, %s, %s, %s)
            """,
            (
                employer["employer_id"],
                job_title,
                description or "",
                required_skills
            )
        )

        db.commit()

        return jsonify({
            "message": "Job posted successfully!"
        }), 201

    except mysql.connector.Error as error:

        db.rollback()

        print("Job posting error:", error)

        return jsonify({
            "message": "Could not post job."
        }), 500

    finally:
        cursor.close()


# ==============================
# EMPLOYER DASHBOARD
# ==============================

@app.route("/employer/dashboard/<int:user_id>", methods=["GET"])
def employer_dashboard(user_id):

    cursor = db.cursor(dictionary=True)

    try:

        # Find employer
        cursor.execute(
            """
            SELECT
                employer_id,
                company_name,
                company_description
            FROM employers
            WHERE user_id = %s
            """,
            (user_id,)
        )

        employer = cursor.fetchone()

        if not employer:

            return jsonify({
                "message": "Employer profile not found."
            }), 404

        employer_id = employer["employer_id"]

        # Employer's jobs
        cursor.execute(
            """
            SELECT
                job_id,
                job_title,
                description,
                required_skills
            FROM jobs
            WHERE employer_id = %s
            ORDER BY job_id DESC
            """,
            (employer_id,)
        )

        jobs = cursor.fetchall()

        # Applicants for employer's jobs
        cursor.execute(
            """
            SELECT
                a.application_id,
                a.user_id,
                a.job_id,
                a.status,
                u.name,
                u.email,
                j.job_title,
                j.description,
                j.required_skills,
                COALESCE(ms.score, 0) AS match_score
            FROM applications a

            JOIN users u
                ON a.user_id = u.user_id

            JOIN jobs j
                ON a.job_id = j.job_id

            JOIN employers e
                ON j.employer_id = e.employer_id

            LEFT JOIN match_scores ms
                ON ms.user_id = a.user_id
                AND ms.job_id = a.job_id

            WHERE e.user_id = %s

            ORDER BY match_score DESC
            """,
            (user_id,)
        )

        applications = cursor.fetchall()

        return jsonify({
            "employer": employer,
            "jobs": jobs,
            "applications": applications
        }), 200

    finally:
        cursor.close()


# ==============================
# UPDATE APPLICATION STATUS
# ==============================

@app.route(
    "/applications/<int:application_id>/status",
    methods=["PUT"]
)
def update_application_status(application_id):

    data = request.get_json()

    status = data.get("status")

    allowed_statuses = [
        "Applied",
        "Shortlisted",
        "Selected",
        "Rejected"
    ]

    if status not in allowed_statuses:

        return jsonify({
            "message": "Invalid application status."
        }), 400

    cursor = db.cursor()

    try:

        cursor.execute(
            """
            UPDATE applications
            SET status = %s
            WHERE application_id = %s
            """,
            (
                status,
                application_id
            )
        )

        if cursor.rowcount == 0:

            return jsonify({
                "message": "Application not found."
            }), 404

        db.commit()

        return jsonify({
            "message": "Application status updated successfully!"
        }), 200

    except mysql.connector.Error as error:

        db.rollback()

        print("Status update error:", error)

        return jsonify({
            "message": "Could not update application status."
        }), 500

    finally:
        cursor.close()


# ==============================
# RUN
# ==============================

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )