import { useEffect, useState } from "react";
import "./App.css";

const API = "http://127.0.0.1:5000";

function App() {
  const [page, setPage] = useState("home");
  const [user, setUser] = useState(null);

  // Register
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [registerMessage, setRegisterMessage] = useState("");

  // Login
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginRole, setLoginRole] = useState("");
  const [loginMessage, setLoginMessage] = useState("");

  // Job seeker
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [resumeFile, setResumeFile] = useState(null);
  const [resumeResult, setResumeResult] = useState(null);
  const [loadingJobs, setLoadingJobs] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Employer
  const [employerData, setEmployerData] = useState(null);
  const [employerJobs, setEmployerJobs] = useState([]);
  const [employerApplications, setEmployerApplications] = useState([]);

  const [jobTitle, setJobTitle] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [requiredSkills, setRequiredSkills] = useState("");
  const [jobMessage, setJobMessage] = useState("");

  const [message, setMessage] = useState("");

  // ============================================================
  // REGISTER
  // ============================================================

  const handleRegister = async (e) => {
    e.preventDefault();
    setRegisterMessage("");

    try {
      const response = await fetch(`${API}/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          email,
          password,
          role,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setRegisterMessage(data.message || "Registration failed.");
        return;
      }

      setRegisterMessage(
        data.message || "Account created successfully!"
      );

      setName("");
      setEmail("");
      setPassword("");
      setRole("");

      setTimeout(() => {
        setPage("login");
      }, 800);
    } catch (error) {
      setRegisterMessage("Could not connect to the backend.");
    }
  };

  // ============================================================
  // LOGIN
  // ============================================================

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginMessage("");

    try {
      const response = await fetch(`${API}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: loginEmail,
          password: loginPassword,
          role: loginRole,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setLoginMessage(
          data.message || "Invalid email, password, or account type."
        );
        return;
      }

      // Backend returns the user directly
      const loggedUser = data;

      setUser(loggedUser);

      if (loggedUser.role === "Job Seeker") {
        setPage("jobseeker");
        loadMatches(loggedUser.user_id);
        loadApplications(loggedUser.user_id);
      } else if (loggedUser.role === "Employer") {
        setPage("employer");
        loadEmployerDashboard(loggedUser.user_id);
      }

      setLoginEmail("");
      setLoginPassword("");
      setLoginRole("");
    } catch (error) {
      console.error("Login error:", error);
      setLoginMessage("Could not connect to the backend.");
    }
  };

  // ============================================================
  // LOAD MATCHES
  // ============================================================

const loadMatches = async (userId) => {
  setLoadingJobs(true);

  try {
    const response = await fetch(`${API}/match-jobs/${userId}`);
    const data = await response.json();

    console.log("MATCH DATA:", data);

    if (response.ok && Array.isArray(data.matches)) {
      setJobs(data.matches);
      return;
    }

    // Fallback: load all jobs instead of showing an empty page
    const jobsResponse = await fetch(`${API}/jobs`);
    const jobsData = await jobsResponse.json();

    if (jobsResponse.ok && Array.isArray(jobsData)) {
      setJobs(
        jobsData.map((job) => ({
          ...job,
          match_score: 0,
        }))
      );
    } else {
      setJobs([]);
    }

  } catch (error) {
    console.error("Error loading jobs:", error);

    // Final fallback
    try {
      const jobsResponse = await fetch(`${API}/jobs`);
      const jobsData = await jobsResponse.json();

      if (jobsResponse.ok && Array.isArray(jobsData)) {
        setJobs(
          jobsData.map((job) => ({
            ...job,
            match_score: 0,
          }))
        );
      } else {
        setJobs([]);
      }
    } catch (fallbackError) {
      console.error(
        "Fallback job loading failed:",
        fallbackError
      );
      setJobs([]);
    }
  } finally {
    setLoadingJobs(false);
  }
};

  // ============================================================
  // RESUME UPLOAD
  // ============================================================

  const handleResumeUpload = async () => {
    if (!resumeFile || !user) {
      setMessage("Please select a resume first.");
      return;
    }

    setUploading(true);
    setMessage("");
    setResumeResult(null);

    const formData = new FormData();

    formData.append("file", resumeFile);
    formData.append("user_id", user.user_id);

    try {
      const response = await fetch(`${API}/upload-resume`, {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || "Resume upload failed.");
        setUploading(false);
        return;
      }

      setResumeResult(data);

      setMessage(
        data.message || "Resume uploaded successfully!"
      );

      await loadMatches(user.user_id);
    } catch (error) {
      setMessage("Could not connect to the backend.");
    }

    setUploading(false);
  };

  // ============================================================
  // APPLY FOR JOB
  // ============================================================

  const applyForJob = async (jobId) => {
    if (!user) return;

    try {
      const response = await fetch(`${API}/apply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: user.user_id,
          job_id: jobId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Application failed.");
        return;
      }

      alert(
        data.message ||
          "Application submitted successfully!"
      );

      loadApplications(user.user_id);
    } catch (error) {
      alert("Could not connect to the backend.");
    }
  };

  // ============================================================
  // LOAD APPLICATIONS
  // ============================================================

 const loadApplications = async (userId) => {
  try {
    const response = await fetch(
      `${API}/applications/${userId}`
    );

    const data = await response.json();

    console.log("APPLICATION DATA:", data);

    if (!response.ok) {
      setApplications([]);
      return;
    }

    // Backend returns the array directly
    if (Array.isArray(data)) {
      setApplications(data);
      return;
    }

    // Also support { applications: [...] }
    if (Array.isArray(data.applications)) {
      setApplications(data.applications);
      return;
    }

    setApplications([]);

  } catch (error) {
    console.error(
      "Could not load applications:",
      error
    );

    setApplications([]);
  }
};

  // ============================================================
  // EMPLOYER DASHBOARD
  // ============================================================

  const loadEmployerDashboard = async (userId) => {
    try {
      const response = await fetch(
        `${API}/employer/dashboard/${userId}`
      );

      const data = await response.json();

      if (response.ok) {
        setEmployerData(data);
        setEmployerJobs(data.jobs || []);
        setEmployerApplications(
          data.applications || []
        );
      }
    } catch (error) {
      console.error(
        "Could not load employer dashboard:",
        error
      );
    }
  };

  // ============================================================
  // POST JOB
  // ============================================================

  const handlePostJob = async (e) => {
    e.preventDefault();

    if (!user) return;

    setJobMessage("");

    try {
      const response = await fetch(
        `${API}/employer/jobs`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            user_id: user.user_id,
            job_title: jobTitle,
            description: jobDescription,
            required_skills: requiredSkills,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setJobMessage(
          data.message || "Could not post job."
        );
        return;
      }

      setJobMessage(
        data.message || "Job posted successfully!"
      );

      setJobTitle("");
      setJobDescription("");
      setRequiredSkills("");

      await loadEmployerDashboard(user.user_id);
    } catch (error) {
      setJobMessage(
        "Could not connect to the backend."
      );
    }
  };

  // ============================================================
  // UPDATE APPLICATION STATUS
  // ============================================================

  const updateApplicationStatus = async (
    applicationId,
    status
  ) => {
    try {
      const response = await fetch(
        `${API}/applications/${applicationId}/status`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            status,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        alert(
          data.message ||
            "Could not update status."
        );
        return;
      }

      alert(
        data.message ||
          "Application status updated."
      );

      loadEmployerDashboard(user.user_id);
    } catch (error) {
      alert(
        "Could not connect to the backend."
      );
    }
  };

  // ============================================================
  // LOGOUT
  // ============================================================

  const logout = () => {
    setUser(null);
    setPage("home");

    setJobs([]);
    setApplications([]);
    setEmployerData(null);
    setEmployerJobs([]);
    setEmployerApplications([]);
    setResumeResult(null);
  };

  // ============================================================
  // HOME
  // ============================================================

  if (page === "home") {
    return (
      <div className="min-vh-100 bg-light">

        <nav className="navbar navbar-dark bg-primary px-4 py-3">

          <div className="container-fluid">

            <span
              className="navbar-brand fw-bold fs-3"
              style={{ cursor: "pointer" }}
              onClick={() => setPage("home")}
            >
              JobMatch
            </span>

            <div className="d-flex gap-2">

              <button
                className="btn btn-light"
                onClick={() =>
                  setPage("register")
                }
              >
                Create Account
              </button>

              <button
                className="btn btn-outline-light"
                onClick={() =>
                  setPage("login")
                }
              >
                Login
              </button>

            </div>

          </div>

        </nav>

        <div className="container py-5">

          <div className="row align-items-center py-5">

            <div className="col-lg-7">

              <span className="badge bg-primary-subtle text-primary mb-3 p-2">
                Smart Recruitment Platform
              </span>

              <h1 className="display-3 fw-bold">

                Find the right job with

                <span className="text-primary">
                  {" "}JobMatch
                </span>

              </h1>

              <p className="lead text-secondary mt-4">
                Upload your resume, automatically
                extract your skills, and discover
                jobs ranked according to your profile.
              </p>

              <div className="mt-4 d-flex gap-3">

                <button
                  className="btn btn-primary btn-lg"
                  onClick={() =>
                    setPage("register")
                  }
                >
                  Get Started
                </button>

                <button
                  className="btn btn-outline-primary btn-lg"
                  onClick={() =>
                    setPage("login")
                  }
                >
                  Login
                </button>

              </div>

            </div>

            <div className="col-lg-5 mt-5 mt-lg-0">

              <div className="card shadow border-0">

                <div className="card-body p-4">

                  <h3 className="fw-bold">
                    Smart Recruitment
                  </h3>

                  <hr />

                  <p>📄 Resume Parsing</p>
                  <p>🎯 Intelligent Job Matching</p>
                  <p>📊 Match Score Calculation</p>
                  <p>🚀 Faster Candidate Shortlisting</p>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>
    );
  }

  // ============================================================
  // REGISTER
  // ============================================================

  if (page === "register") {
    return (
      <div className="min-vh-100 bg-light d-flex align-items-center py-5">

        <div className="container">

          <div className="row justify-content-center">

            <div className="col-md-6 col-lg-5">

              <div className="card shadow border-0">

                <div className="card-body p-4 p-md-5">

                  <h2 className="fw-bold mb-2">
                    Create Account
                  </h2>

                  <p className="text-secondary">
                    Join JobMatch today.
                  </p>

                  <form
                    onSubmit={handleRegister}
                  >

                    <div className="mb-3">

                      <label className="form-label">
                        Full Name
                      </label>

                      <input
                        type="text"
                        className="form-control"
                        value={name}
                        onChange={(e) =>
                          setName(e.target.value)
                        }
                        required
                      />

                    </div>

                    <div className="mb-3">

                      <label className="form-label">
                        Email
                      </label>

                      <input
                        type="email"
                        className="form-control"
                        value={email}
                        onChange={(e) =>
                          setEmail(e.target.value)
                        }
                        required
                      />

                    </div>

                    <div className="mb-3">

                      <label className="form-label">
                        Password
                      </label>

                      <input
                        type="password"
                        className="form-control"
                        value={password}
                        onChange={(e) =>
                          setPassword(e.target.value)
                        }
                        required
                      />

                    </div>

                    <div className="mb-4">

                      <label className="form-label">
                        Account Type
                      </label>

                      <select
                        className="form-select"
                        value={role}
                        onChange={(e) =>
                          setRole(e.target.value)
                        }
                        required
                      >

                        <option value="">
                          Select account type
                        </option>

                        <option value="Job Seeker">
                          Job Seeker
                        </option>

                        <option value="Employer">
                          Employer
                        </option>

                      </select>

                    </div>

                    <button
                      type="submit"
                      className="btn btn-primary w-100"
                    >
                      Create Account
                    </button>

                  </form>

                  {registerMessage && (
                    <div className="alert alert-info mt-3">
                      {registerMessage}
                    </div>
                  )}

                  <button
                    className="btn btn-link w-100 mt-2"
                    onClick={() =>
                      setPage("home")
                    }
                  >
                    ← Back to Home
                  </button>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>
    );
  }

  // ============================================================
  // LOGIN
  // ============================================================

  if (page === "login") {
    return (
      <div className="min-vh-100 bg-light d-flex align-items-center">

        <div className="container">

          <div className="row justify-content-center">

            <div className="col-md-6 col-lg-5">

              <div className="card shadow border-0">

                <div className="card-body p-4 p-md-5">

                  <h2 className="fw-bold">
                    Welcome Back
                  </h2>

                  <p className="text-secondary mb-4">
                    Login to your JobMatch account.
                  </p>

                  <form
                    onSubmit={handleLogin}
                  >

                    <div className="mb-3">

                      <label className="form-label">
                        Email
                      </label>

                      <input
                        type="email"
                        className="form-control"
                        value={loginEmail}
                        onChange={(e) =>
                          setLoginEmail(
                            e.target.value
                          )
                        }
                        required
                      />

                    </div>

                    <div className="mb-4">

                      <label className="form-label">
                        Password
                      </label>

                      <input
                        type="password"
                        className="form-control"
                        value={loginPassword}
                        onChange={(e) =>
                          setLoginPassword(
                            e.target.value
                          )
                        }
                        required
                      />

                    </div>

                    <div className="mb-4">

                      <label className="form-label">
                        Account Type
                      </label>

                      <select
                        className="form-select"
                        value={loginRole}
                        onChange={(e) =>
                          setLoginRole(e.target.value)
                        }
                        required
                      >

                        <option value="">
                          Select account type
                        </option>

                        <option value="Job Seeker">
                          Job Seeker
                        </option>

                        <option value="Employer">
                          Employer
                        </option>

                      </select>

                    </div>

                    <button
                      type="submit"
                      className="btn btn-primary w-100"
                    >
                      Login
                    </button>

                  </form>

                  {loginMessage && (
                    <div className="alert alert-danger mt-3">
                      {loginMessage}
                    </div>
                  )}

                  <button
                    className="btn btn-link w-100 mt-2"
                    onClick={() =>
                      setPage("home")
                    }
                  >
                    ← Back to Home
                  </button>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>
    );
  }

  // ============================================================
  // JOB SEEKER DASHBOARD
  // ============================================================

  if (page === "jobseeker") {
    return (
      <div className="min-vh-100 bg-light">

        <nav className="navbar navbar-dark bg-primary px-4">

          <span className="navbar-brand fw-bold">
            JobMatch
          </span>

          <div className="d-flex align-items-center gap-3">

            <span className="text-white">
              {user?.name}
            </span>

            <button
              className="btn btn-outline-light btn-sm"
              onClick={logout}
            >
              Logout
            </button>

          </div>

        </nav>

        <div className="container py-4">

          <div className="mb-4">

            <h2 className="fw-bold">
              Welcome, {user?.name} 👋
            </h2>

            <p className="text-secondary">
              Manage your resume and discover jobs
              matched to your skills.
            </p>

          </div>

          {/* RESUME UPLOAD */}

          <div className="card shadow-sm border-0 mb-4">

            <div className="card-body">

              <h4 className="fw-bold">
                📄 Upload Resume
              </h4>

              <p className="text-secondary">
                Upload a PDF or DOCX resume for
                automatic screening.
              </p>

              <div className="row g-2">

                <div className="col-md-8">

                  <input
                    type="file"
                    className="form-control"
                    accept=".pdf,.docx"
                    onChange={(e) =>
                      setResumeFile(
                        e.target.files[0]
                      )
                    }
                  />

                </div>

                <div className="col-md-4">

                  <button
                    className="btn btn-primary w-100"
                    onClick={handleResumeUpload}
                    disabled={uploading}
                  >
                    {uploading
                      ? "Analyzing..."
                      : "Upload & Analyze"}
                  </button>

                </div>

              </div>

              {message && (
                <div className="alert alert-info mt-3 mb-0">
                  {message}
                </div>
              )}

            </div>

          </div>

          {/* RESUME SCREENING */}

          {resumeResult && (
            <div className="card shadow-sm border-0 mb-4">

              <div className="card-body">

                <h4 className="fw-bold mb-3">
                  🔍 Resume Screening Results
                </h4>

                <div className="row g-3">

                  <div className="col-md-6">

                    <div className="card bg-light border-0 h-100">

                      <div className="card-body">

                        <h6 className="fw-bold">
                          Skills
                        </h6>

                        <p>
                          {resumeResult.skills ||
                            resumeResult.extracted_skills ||
                            "Not detected"}
                        </p>

                      </div>

                    </div>

                  </div>

                  <div className="col-md-6">

                    <div className="card bg-light border-0 h-100">

                      <div className="card-body">

                        <h6 className="fw-bold">
                          Education
                        </h6>

                        <p>
                          {resumeResult.education ||
                            "Not detected"}
                        </p>

                      </div>

                    </div>

                  </div>

                  <div className="col-md-6">

                    <div className="card bg-light border-0 h-100">

                      <div className="card-body">

                        <h6 className="fw-bold">
                          Experience
                        </h6>

                        <p>
                          {resumeResult.experience ||
                            "Not detected"}
                        </p>

                      </div>

                    </div>

                  </div>

                  <div className="col-md-6">

                    <div className="card bg-light border-0 h-100">

                      <div className="card-body">

                        <h6 className="fw-bold">
                          Certifications
                        </h6>

                        <p>
                          {resumeResult.certifications ||
                            "Not detected"}
                        </p>

                      </div>

                    </div>

                  </div>

                </div>

              </div>

            </div>
          )}

          {/* JOBS */}

          <div className="d-flex justify-content-between align-items-center mb-3">

            <div>

              <h3 className="fw-bold mb-1">
                Recommended Jobs
              </h3>

              <p className="text-secondary mb-0">
                Jobs ranked according to your resume skills.
              </p>

            </div>

            <button
              className="btn btn-outline-primary btn-sm"
              onClick={() =>
                user && loadMatches(user.user_id)
              }
            >
              Refresh Matches
            </button>

          </div>

          {loadingJobs ? (

            <div className="text-center py-5">
              Loading jobs...
            </div>

          ) : jobs.length === 0 ? (

            <div className="alert alert-warning">
              No jobs available yet.
            </div>

          ) : (

            <div className="row g-4">

              {jobs.map((job) => (

                <div
                  className="col-md-6 col-lg-4"
                  key={job.job_id}
                >

                  <div className="card h-100 shadow-sm border-0">

                    <div className="card-body">

                      <div className="d-flex justify-content-between align-items-start">

                        <h5 className="fw-bold">
                          {job.job_title}
                        </h5>

                        <span
                          className={`badge ${
                            Number(job.match_score) >= 50
                              ? "bg-success"
                              : Number(job.match_score) > 0
                              ? "bg-warning text-dark"
                              : "bg-secondary"
                          }`}
                        >
                          {job.match_score}%
                        </span>

                      </div>

                      <p className="text-secondary">
                        {job.description}
                      </p>

                      <h6 className="fw-bold">
                        Required Skills:
                      </h6>

                      <p className="small">
                        {job.required_skills}
                      </p>

                      <div className="progress mb-3">

                        <div
                          className="progress-bar"
                          style={{
                            width: `${Math.min(
                              Number(job.match_score) || 0,
                              100
                            )}%`,
                          }}
                        >
                          {job.match_score}%
                        </div>

                      </div>

                      <button
                        className="btn btn-primary w-100"
                        onClick={() =>
                          applyForJob(job.job_id)
                        }
                      >
                        Apply Now
                      </button>

                    </div>

                  </div>

                </div>

              ))}

            </div>

          )}

          {/* MY APPLICATIONS */}

          <div className="mt-5">

            <div className="d-flex justify-content-between align-items-center mb-3">

              <h3 className="fw-bold">
                📋 My Applications
              </h3>

              <button
                className="btn btn-outline-secondary btn-sm"
                onClick={() =>
                  loadApplications(
                    user.user_id
                  )
                }
              >
                Refresh
              </button>

            </div>

            {applications.length === 0 ? (

              <div className="alert alert-light border">
                You have not applied for any jobs yet.
              </div>

            ) : (

              <div className="table-responsive">

                <table className="table table-bordered table-hover bg-white">

                  <thead className="table-light">

                    <tr>
                      <th>Job</th>
                      <th>Company</th>
                      <th>Status</th>
                    </tr>

                  </thead>

                  <tbody>

                    {applications.map(
                      (app) => (

                        <tr
                          key={
                            app.application_id
                          }
                        >

                          <td>
                            {app.job_title ||
                              app.title}
                          </td>

                          <td>
                            {app.company_name ||
                              "—"}
                          </td>

                          <td>

                            <span
                              className={`badge ${
                                app.status ===
                                "Selected"
                                  ? "bg-success"
                                  : app.status ===
                                    "Rejected"
                                  ? "bg-danger"
                                  : app.status ===
                                    "Shortlisted"
                                  ? "bg-primary"
                                  : "bg-warning text-dark"
                              }`}
                            >
                              {app.status}
                            </span>

                          </td>

                        </tr>

                      )
                    )}

                  </tbody>

                </table>

              </div>

            )}

          </div>

        </div>

      </div>
    );
  }

  // ============================================================
  // EMPLOYER DASHBOARD
  // ============================================================

  if (page === "employer") {
    return (
      <div className="min-vh-100 bg-light">

        <nav className="navbar navbar-dark bg-primary px-4">

          <span className="navbar-brand fw-bold">
            JobMatch
          </span>

          <div className="d-flex align-items-center gap-3">

            <span className="text-white">
              {user?.name}
            </span>

            <button
              className="btn btn-outline-light btn-sm"
              onClick={logout}
            >
              Logout
            </button>

          </div>

        </nav>

        <div className="container py-4">

          <div className="mb-4">

            <h2 className="fw-bold">
              Employer Dashboard 🏢
            </h2>

            <p className="text-secondary">
              Post jobs and manage candidates.
            </p>

          </div>

          {/* STATISTICS */}

          <div className="row g-3 mb-4">

            <div className="col-md-4">

              <div className="card border-0 shadow-sm">

                <div className="card-body">

                  <h6 className="text-secondary">
                    Active Jobs
                  </h6>

                  <h2 className="fw-bold">
                    {employerJobs.length}
                  </h2>

                </div>

              </div>

            </div>

            <div className="col-md-4">

              <div className="card border-0 shadow-sm">

                <div className="card-body">

                  <h6 className="text-secondary">
                    Applicants
                  </h6>

                  <h2 className="fw-bold">
                    {employerApplications.length}
                  </h2>

                </div>

              </div>

            </div>

            <div className="col-md-4">

              <div className="card border-0 shadow-sm">

                <div className="card-body">

                  <h6 className="text-secondary">
                    Matched Candidates
                  </h6>

                  <h2 className="fw-bold">
                    {
                      employerApplications.filter(
                        (a) =>
                          Number(
                            a.match_score || 0
                          ) > 0
                      ).length
                    }
                  </h2>

                </div>

              </div>

            </div>

          </div>

          {/* POST JOB */}

          <div className="card border-0 shadow-sm mb-4">

            <div className="card-body">

              <h4 className="fw-bold mb-3">
                ➕ Post a Job
              </h4>

              <form onSubmit={handlePostJob}>

                <div className="mb-3">

                  <label className="form-label">
                    Job Title
                  </label>

                  <input
                    className="form-control"
                    placeholder="Example: Python Developer"
                    value={jobTitle}
                    onChange={(e) =>
                      setJobTitle(
                        e.target.value
                      )
                    }
                    required
                  />

                </div>

                <div className="mb-3">

                  <label className="form-label">
                    Job Description
                  </label>

                  <textarea
                    className="form-control"
                    rows="3"
                    placeholder="Describe the role..."
                    value={jobDescription}
                    onChange={(e) =>
                      setJobDescription(
                        e.target.value
                      )
                    }
                    required
                  />

                </div>

                <div className="mb-3">

                  <label className="form-label">
                    Required Skills
                  </label>

                  <input
                    className="form-control"
                    placeholder="Python, Flask, SQL, Git"
                    value={requiredSkills}
                    onChange={(e) =>
                      setRequiredSkills(
                        e.target.value
                      )
                    }
                    required
                  />

                </div>

                <button
                  className="btn btn-primary"
                  type="submit"
                >
                  Post Job
                </button>

              </form>

              {jobMessage && (
                <div className="alert alert-info mt-3 mb-0">
                  {jobMessage}
                </div>
              )}

            </div>

          </div>

          {/* YOUR JOBS */}

          <div className="card border-0 shadow-sm mb-4">

            <div className="card-body">

              <div className="d-flex justify-content-between align-items-center mb-3">

                <h4 className="fw-bold mb-0">
                  💼 Your Jobs
                </h4>

                <button
                  className="btn btn-outline-primary btn-sm"
                  onClick={() =>
                    loadEmployerDashboard(
                      user.user_id
                    )
                  }
                >
                  Refresh
                </button>

              </div>

              {employerJobs.length === 0 ? (

                <p className="text-secondary">
                  No jobs posted yet.
                </p>

              ) : (

                <div className="row g-3">

                  {employerJobs.map(
                    (job) => (

                      <div
                        className="col-md-6"
                        key={job.job_id}
                      >

                        <div className="card bg-light border-0 h-100">

                          <div className="card-body">

                            <h5 className="fw-bold">
                              {job.job_title ||
                                job.title}
                            </h5>

                            <p>
                              {job.description}
                            </p>

                            <p className="small mb-0">

                              <strong>
                                Skills:
                              </strong>{" "}

                              {job.required_skills}

                            </p>

                          </div>

                        </div>

                      </div>

                    )
                  )}

                </div>

              )}

            </div>

          </div>

          {/* APPLICANTS */}

          <div className="card border-0 shadow-sm">

            <div className="card-body">

              <h4 className="fw-bold mb-3">
                👥 Applicants & Match Scores
              </h4>

              {employerApplications.length === 0 ? (

                <div className="alert alert-light border">
                  No applicants yet.
                </div>

              ) : (

                <div className="table-responsive">

                  <table className="table table-bordered table-hover">

                    <thead className="table-light">

                      <tr>

                        <th>Candidate</th>
                        <th>Email</th>
                        <th>Job</th>
                        <th>Match Score</th>
                        <th>Status</th>
                        <th>Update</th>

                      </tr>

                    </thead>

                    <tbody>

                      {[
                        ...employerApplications,
                      ]
                        .sort(
                          (a, b) =>
                            Number(
                              b.match_score || 0
                            ) -
                            Number(
                              a.match_score || 0
                            )
                        )
                        .map(
                          (app) => (

                            <tr
                              key={
                                app.application_id
                              }
                            >

                              <td>
                                {app.name ||
                                  app.candidate_name ||
                                  "Candidate"}
                              </td>

                              <td>
                                {app.email ||
                                  "—"}
                              </td>

                              <td>
                                {app.job_title ||
                                  app.title}
                              </td>

                              <td>

                                <span className="badge bg-primary">

                                  {app.match_score ||
                                    0}
                                  %

                                </span>

                              </td>

                              <td>

                                <span
                                  className={`badge ${
                                    app.status ===
                                    "Selected"
                                      ? "bg-success"
                                      : app.status ===
                                        "Rejected"
                                      ? "bg-danger"
                                      : app.status ===
                                        "Shortlisted"
                                      ? "bg-primary"
                                      : "bg-warning text-dark"
                                  }`}
                                >
                                  {app.status}
                                </span>

                              </td>

                              <td>

                                <select
                                  className="form-select form-select-sm"
                                  value={
                                    app.status ||
                                    "Applied"
                                  }
                                  onChange={(e) =>
                                    updateApplicationStatus(
                                      app.application_id,
                                      e.target.value
                                    )
                                  }
                                >

                                  <option value="Applied">
                                    Applied
                                  </option>

                                  <option value="Shortlisted">
                                    Shortlisted
                                  </option>

                                  <option value="Selected">
                                    Selected
                                  </option>

                                  <option value="Rejected">
                                    Rejected
                                  </option>

                                </select>

                              </td>

                            </tr>

                          )
                        )}

                    </tbody>

                  </table>

                </div>

              )}

            </div>

          </div>

        </div>

      </div>
    );
  }

  return null;
}

export default App;